Date.weekdays = $w('Mo Di Mi Do Fr Sa So');
Date.months = $w('Januar Februar März April Mai Juni Juli August September Oktober November Dezember');

Date.first_day_of_week = 1;

_translations = {
  "OK": "OK",
  "Now": "Jetzt",
  "Today": "Heute",
  "Clear": "Löschen"
}
